



/* TAREFA #14906 - LÉIA */


/****** Object:  View [dbo].[RelatorioBaseTributacao]    Script Date: 09/02/2022 09:18:28 ******/

CREATE VIEW [dbo].[RelatorioBaseTributacao] AS
select 	
	[MovTrn01].[EstCod] as RelBaseTribCodigo,
	[EST].[EstAplPsq] as RelBaseTribEstabelecimento,
	[EST].[EstSegmento] as RelBaseTribSegmentos,
	[EST].[EstNomFan] as RelBaseTribNomeFantasia,
	[EST].[EstCpfCnpj] as RelBaseTribCNPJ,
	[EST].[EstTip] as RelBaseTribEstTipo,
	movtrndta as RelBaseTribData,
	sum(MovTrnVlr) as RelBaseTribValorVenda, 	  
	sum(MovTrnVlrLiqEst) as RelBaseTribValorEstabelecimento,		
	sum(MovTrnBfaVlrTxaAdm) as RelBaseTribTaxaAdministracao,	
	sum(MovTrnBfaVlrTxaFin) as RelBaseTribReceitaAntecipacao,
	sum(MovTrnGbpVlrTxaInt) as RelBaseTribTaxaAdquirente,
	sum(MovTrnVlr - MovTrnVlrLiqEst - MovTrnGbpVlrTxaInt) as RelBaseTribReceitaLiquida
from [MovTrn01]
	left join [EST] on [EST].[EstCod] = [MovTrn01].[EstCod]
	Where MovTrnCod in ('CV', 'CC')
	group by [MovTrn01].[EstCod], EstNomFan, EstAplPsq, EstCpfCnpj, EstTip, EstSegmento, movtrndta

GO


/* TAREFA #15186 - JOSÉ */

/* AUXILIAR CONTÁBIL */

--Quais bancos precisam do script abaixo
USE auxiliar_contabil

--Criação de Tabela AUXCTBLan
CREATE TABLE [AUXCTBLan] (
  [AUXCTBLanId]        DECIMAL(10)     NOT NULL     IDENTITY ( 1 , 1 ),
  [AUXCTBLanUngId]     SMALLINT     NOT NULL,
  [AUXCTBLanDtaMov]    DATETIME     NOT NULL,
  [AUXCTBLanCCDeb]     VARCHAR(20)     NOT NULL,
  [AUXCTBLanDscCCDeb]  VARCHAR(50)     NOT NULL,
  [AUXCTBLanCCCre]     VARCHAR(20)     NOT NULL,
  [AUXCTBLanDscCCCre]  VARCHAR(50)     NOT NULL,
  [AUXCTBLanNumOpe]    VARCHAR(20)     NOT NULL,
  [AUXCTBLanHistorico] VARCHAR(50)     NOT NULL,
  [AUXCTBLanDtaOpe]    DATETIME     NOT NULL,
  [AUXCTBLanValor]     DECIMAL(17,2)     NOT NULL,
  [AUXCTBLanEstCod]       INT     NOT NULL,
  [AUXCTBLanNomLoja]     VARCHAR(100)     NOT NULL,
      PRIMARY KEY ( [AUXCTBLanId] ))

/* PRONTO */

 --Quais bancos precisam do script abaixo
USE Pronto
 
 CREATE NONCLUSTERED INDEX [UMOVTRN014] ON [MovTrn01] (
      [MovTrnDta] DESC)

--Parâmetro do caminho de onde irá ser gerado o CSV de Lançamentos Auxiliar Contábil
INSERT INTO PARSIS
VALUES ('AUXCTBLancamento_CSV', 'Caminho de onde irá ser gerado o CSV de Lançamentos Auxiliar Contábil', 'VA', 200, NULL, 'N', 
'/mnt/home1/SubAdquirencia/025/contabil/', 'ADMIN', '2022-02-09 00:00:00:000', NULL, NULL, 0)


/* TAREFA #15139 - CARLOS */

--Use BancoOrigem
--Use Banese
--Use BemFacil
--Use CredInov
--Use CredPag
--Use Pronto
--Use Smartpagamentos

--INSERT INTO TLog0002 VALUES ('ANTPAG', 'Antecipação Pagamento',0)
--select top 1 * from TLog0002 ORDER BY TLOGID DESC /*VERIFICAR QUAL TLogID*/
--INSERT INTO TLog0003 VALUES (/*TLogID Criado*/,1,'AnpNumPag', 'Número Antecipação')
--select top 1 * from TLog0003 ORDER BY TLOGID DESC /*VERIFICAR QUAL TLogID*/

/*VERIFICAR SE GRAVOU*/
--select top 3 * from TLog0002 ORDER BY TLOGID DESC 
--select top 3 * from TLog0003 ORDER BY TLOGID DESC


/* TAREFA #14868 - Wesley */

CREATE NONCLUSTERED INDEX [UTRN05] ON [TRN05] (
      [TrnBrsRdeSit],
      [TrnBrsOprSitPrc],
      [TrnBrsFecSeqArq])


/* ALTERAÇÃO DA VERSÃO DO BANCO */
USE Banese
USE Bemfacil
USE Credinov
USE Credpag
USE Pronto
USE SmartPagamentos

UPDATE PARSIS
SET ParCon = '2.5.9'
WHERE ParCod = 'VERSAO_BANCO'

UPDATE PARSIS
SET ParCon = '10/02/2022'
WHERE ParCod = 'VERSAO_BANCO_DATA'